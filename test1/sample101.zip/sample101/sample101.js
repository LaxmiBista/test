'use strict';

alert("This is Test!");
